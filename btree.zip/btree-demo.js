const { BTree } = require('./btree');

console.log('═══════════════════════════════════════════');
console.log('           B-Tree Demonstration            ');
console.log('═══════════════════════════════════════════\n');

// Create a B-tree with minimum degree 2 (2-3-4 tree)
// Max keys per node: 2*2-1 = 3
// Min keys per non-root node: 2-1 = 1
console.log('Creating B-tree with minimum degree t=2');
console.log('(Each node can have 1-3 keys, 2-4 children)\n');

const tree = new BTree(2);

// Insert values
const values = [10, 20, 5, 6, 12, 30, 7, 17, 3, 25, 15, 8];
console.log('Inserting:', values.join(', '));
console.log('');

for (const val of values) {
  tree.insert(val);
  console.log(`After inserting ${val}:`);
  tree.print();
  tree.validate();
  console.log('');
}

console.log('───────────────────────────────────────────');
console.log('Tree Statistics:');
console.log('───────────────────────────────────────────');
console.log('  Size:', tree.size());
console.log('  Height:', tree.height());
console.log('  Min:', tree.min());
console.log('  Max:', tree.max());
console.log('  In-order:', tree.inOrder().join(', '));
console.log('');

console.log('───────────────────────────────────────────');
console.log('Search Operations:');
console.log('───────────────────────────────────────────');
console.log('  Contains 17?', tree.contains(17));
console.log('  Contains 100?', tree.contains(100));
console.log('  Contains 5?', tree.contains(5));
console.log('');

console.log('───────────────────────────────────────────');
console.log('Deletion Operations:');
console.log('───────────────────────────────────────────\n');

const deletions = [6, 30, 10, 7];
for (const val of deletions) {
  console.log(`Deleting ${val}:`);
  const result = tree.delete(val);
  console.log(`  Deleted: ${result}`);
  tree.print();
  tree.validate();
  console.log('  In-order:', tree.inOrder().join(', '));
  console.log('');
}

// Test with higher degree
console.log('\n═══════════════════════════════════════════');
console.log('   Higher Degree B-Tree (t=3)             ');
console.log('═══════════════════════════════════════════\n');

console.log('Creating B-tree with minimum degree t=3');
console.log('(Each node can have 2-5 keys, 3-6 children)\n');

const tree3 = new BTree(3);
const moreValues = Array.from({ length: 25 }, (_, i) => i + 1);
console.log('Inserting 1 through 25...\n');

for (const val of moreValues) {
  tree3.insert(val);
}

console.log('Final tree structure:');
tree3.print();
tree3.validate();

console.log('\nStatistics:');
console.log('  Size:', tree3.size());
console.log('  Height:', tree3.height());

// Test validation catches errors
console.log('\n═══════════════════════════════════════════');
console.log('   Stress Test & Validation               ');
console.log('═══════════════════════════════════════════\n');

const stressTree = new BTree(3);
const stressValues = [];

// Insert 100 random values
for (let i = 0; i < 100; i++) {
  const val = Math.floor(Math.random() * 1000);
  if (!stressTree.contains(val)) {
    stressValues.push(val);
    stressTree.insert(val);
  }
}

console.log(`Inserted ${stressValues.length} unique random values`);
console.log(`Tree size: ${stressTree.size()}`);
console.log(`Tree height: ${stressTree.height()}`);

// Verify in-order traversal is sorted
const inorder = stressTree.inOrder();
const isSorted = inorder.every((v, i) => i === 0 || v > inorder[i-1]);
console.log(`In-order is sorted: ${isSorted}`);

// Validate tree invariants
try {
  stressTree.validate();
  console.log('Tree validation passed!');
} catch (e) {
  console.log('Tree validation failed:', e.message);
}

// Delete half the values
console.log('\nDeleting half the values...');
const toDelete = stressValues.slice(0, Math.floor(stressValues.length / 2));
for (const val of toDelete) {
  stressTree.delete(val);
}

console.log(`Tree size after deletions: ${stressTree.size()}`);
console.log(`Tree height: ${stressTree.height()}`);

try {
  stressTree.validate();
  console.log('Tree validation passed after deletions!');
} catch (e) {
  console.log('Tree validation failed:', e.message);
}

console.log('\n✓ All tests completed successfully!');
