/**
 * B-Tree Implementation in Node.js
 * 
 * A B-tree is a self-balancing tree data structure that maintains sorted data
 * and allows searches, insertions, and deletions in logarithmic time.
 * 
 * Properties for a B-tree of minimum degree t:
 * - Every node has at most 2t-1 keys
 * - Every non-root node has at least t-1 keys
 * - Root has at least 1 key (if non-empty)
 * - All leaves are at the same level
 * - A node with n keys has n+1 children (if internal)
 */

class BTreeNode {
  constructor(isLeaf = true) {
    this.keys = [];      // Array of keys
    this.children = [];  // Array of child nodes
    this.isLeaf = isLeaf;
  }
}

class BTree {
  /**
   * Create a new B-tree
   * @param {number} t - Minimum degree (minimum 2)
   *   - Each node can have at most 2t-1 keys
   *   - Each non-root node must have at least t-1 keys
   */
  constructor(t = 2) {
    if (t < 2) {
      throw new Error('Minimum degree must be at least 2');
    }
    this.t = t;
    this.root = new BTreeNode(true);
  }

  /**
   * Search for a key in the B-tree
   * @param {*} key - The key to search for
   * @param {BTreeNode} node - Starting node (defaults to root)
   * @returns {{node: BTreeNode, index: number} | null}
   */
  search(key, node = this.root) {
    let i = 0;
    
    // Find first key >= search key
    while (i < node.keys.length && key > node.keys[i]) {
      i++;
    }
    
    // Found the key
    if (i < node.keys.length && key === node.keys[i]) {
      return { node, index: i };
    }
    
    // Reached a leaf without finding key
    if (node.isLeaf) {
      return null;
    }
    
    // Recurse to appropriate child
    return this.search(key, node.children[i]);
  }

  /**
   * Check if a key exists
   */
  contains(key) {
    return this.search(key) !== null;
  }

  /**
   * Insert a key into the B-tree
   */
  insert(key) {
    const root = this.root;
    
    // If root is full, split it and create new root
    if (root.keys.length === 2 * this.t - 1) {
      const newRoot = new BTreeNode(false);
      newRoot.children.push(this.root);
      this.root = newRoot;
      this._splitChild(newRoot, 0);
      this._insertNonFull(newRoot, key);
    } else {
      this._insertNonFull(root, key);
    }
  }

  /**
   * Split the i-th child of node (which must be full)
   * @private
   */
  _splitChild(parent, i) {
    const t = this.t;
    const fullChild = parent.children[i];
    
    // Create new node to hold right half
    const newChild = new BTreeNode(fullChild.isLeaf);
    
    // Middle key will move up to parent
    const midIndex = t - 1;
    const midKey = fullChild.keys[midIndex];
    
    // Copy right half of keys to new child (keys after middle)
    newChild.keys = fullChild.keys.slice(t);
    
    // Keep only left half of keys in original child (keys before middle)
    fullChild.keys = fullChild.keys.slice(0, midIndex);
    
    // If not a leaf, split children too
    if (!fullChild.isLeaf) {
      newChild.children = fullChild.children.slice(t);
      fullChild.children = fullChild.children.slice(0, t);
    }
    
    // Insert new child and middle key into parent
    parent.children.splice(i + 1, 0, newChild);
    parent.keys.splice(i, 0, midKey);
  }

  /**
   * Insert into a node that is not full
   * @private
   */
  _insertNonFull(node, key) {
    let i = node.keys.length - 1;
    
    if (node.isLeaf) {
      // Find position and insert
      while (i >= 0 && key < node.keys[i]) {
        i--;
      }
      node.keys.splice(i + 1, 0, key);
    } else {
      // Find child to recurse into
      while (i >= 0 && key < node.keys[i]) {
        i--;
      }
      i++;
      
      // Split child if full
      if (node.children[i].keys.length === 2 * this.t - 1) {
        this._splitChild(node, i);
        if (key > node.keys[i]) {
          i++;
        }
      }
      
      this._insertNonFull(node.children[i], key);
    }
  }

  /**
   * Delete a key from the B-tree
   * @returns {boolean} - True if key was deleted
   */
  delete(key) {
    if (this.root.keys.length === 0) {
      return false;
    }
    
    const deleted = this._delete(this.root, key);
    
    // Shrink tree if root is empty but has children
    if (this.root.keys.length === 0 && !this.root.isLeaf) {
      this.root = this.root.children[0];
    }
    
    return deleted;
  }

  /**
   * Internal delete
   * @private
   */
  _delete(node, key) {
    const t = this.t;
    let i = 0;
    
    while (i < node.keys.length && key > node.keys[i]) {
      i++;
    }
    
    // Case 1: Key in this node
    if (i < node.keys.length && key === node.keys[i]) {
      if (node.isLeaf) {
        // Case 1a: Leaf - just remove
        node.keys.splice(i, 1);
        return true;
      } else {
        // Case 1b: Internal node
        return this._deleteFromInternal(node, i);
      }
    }
    
    // Key not in this node
    if (node.isLeaf) {
      return false;
    }
    
    // Ensure child has enough keys
    if (node.children[i].keys.length < t) {
      this._fill(node, i);
    }
    
    // Recalculate index after possible merge
    if (i > node.keys.length) {
      i--;
    }
    
    return this._delete(node.children[i], key);
  }

  /**
   * Delete from internal node
   * @private
   */
  _deleteFromInternal(node, keyIndex) {
    const key = node.keys[keyIndex];
    const t = this.t;
    
    // Case 2a: Left child has >= t keys
    if (node.children[keyIndex].keys.length >= t) {
      const pred = this._getPredecessor(node, keyIndex);
      node.keys[keyIndex] = pred;
      return this._delete(node.children[keyIndex], pred);
    }
    
    // Case 2b: Right child has >= t keys
    if (node.children[keyIndex + 1].keys.length >= t) {
      const succ = this._getSuccessor(node, keyIndex);
      node.keys[keyIndex] = succ;
      return this._delete(node.children[keyIndex + 1], succ);
    }
    
    // Case 2c: Both have t-1 keys - merge
    this._merge(node, keyIndex);
    return this._delete(node.children[keyIndex], key);
  }

  /**
   * Get predecessor (largest in left subtree)
   * @private
   */
  _getPredecessor(node, keyIndex) {
    let cur = node.children[keyIndex];
    while (!cur.isLeaf) {
      cur = cur.children[cur.keys.length];
    }
    return cur.keys[cur.keys.length - 1];
  }

  /**
   * Get successor (smallest in right subtree)
   * @private
   */
  _getSuccessor(node, keyIndex) {
    let cur = node.children[keyIndex + 1];
    while (!cur.isLeaf) {
      cur = cur.children[0];
    }
    return cur.keys[0];
  }

  /**
   * Ensure child[i] has >= t keys
   * @private
   */
  _fill(node, i) {
    const t = this.t;
    
    if (i > 0 && node.children[i - 1].keys.length >= t) {
      this._borrowFromPrev(node, i);
    } else if (i < node.children.length - 1 && node.children[i + 1].keys.length >= t) {
      this._borrowFromNext(node, i);
    } else {
      // Merge with sibling
      if (i < node.keys.length) {
        this._merge(node, i);
      } else {
        this._merge(node, i - 1);
      }
    }
  }

  /**
   * Borrow from left sibling
   * @private
   */
  _borrowFromPrev(node, i) {
    const child = node.children[i];
    const sibling = node.children[i - 1];
    
    child.keys.unshift(node.keys[i - 1]);
    node.keys[i - 1] = sibling.keys.pop();
    
    if (!child.isLeaf) {
      child.children.unshift(sibling.children.pop());
    }
  }

  /**
   * Borrow from right sibling
   * @private
   */
  _borrowFromNext(node, i) {
    const child = node.children[i];
    const sibling = node.children[i + 1];
    
    child.keys.push(node.keys[i]);
    node.keys[i] = sibling.keys.shift();
    
    if (!child.isLeaf) {
      child.children.push(sibling.children.shift());
    }
  }

  /**
   * Merge child[i] with child[i+1]
   * @private
   */
  _merge(node, i) {
    const leftChild = node.children[i];
    const rightChild = node.children[i + 1];
    
    // Pull down key from parent
    leftChild.keys.push(node.keys[i]);
    
    // Append right child's keys
    leftChild.keys = leftChild.keys.concat(rightChild.keys);
    
    // Append right child's children
    if (!leftChild.isLeaf) {
      leftChild.children = leftChild.children.concat(rightChild.children);
    }
    
    // Remove from parent
    node.keys.splice(i, 1);
    node.children.splice(i + 1, 1);
  }

  /**
   * Get all keys in sorted order
   */
  inOrder() {
    const result = [];
    this._inOrder(this.root, result);
    return result;
  }

  /** @private */
  _inOrder(node, result) {
    for (let i = 0; i < node.keys.length; i++) {
      if (!node.isLeaf) {
        this._inOrder(node.children[i], result);
      }
      result.push(node.keys[i]);
    }
    if (!node.isLeaf) {
      this._inOrder(node.children[node.keys.length], result);
    }
  }

  /** Get minimum key */
  min() {
    if (this.root.keys.length === 0) return undefined;
    let cur = this.root;
    while (!cur.isLeaf) cur = cur.children[0];
    return cur.keys[0];
  }

  /** Get maximum key */
  max() {
    if (this.root.keys.length === 0) return undefined;
    let cur = this.root;
    while (!cur.isLeaf) cur = cur.children[cur.keys.length];
    return cur.keys[cur.keys.length - 1];
  }

  /** Get tree height */
  height() {
    let h = 0;
    let cur = this.root;
    while (!cur.isLeaf) {
      h++;
      cur = cur.children[0];
    }
    return h;
  }

  /** Get total number of keys */
  size() {
    return this._size(this.root);
  }

  /** @private */
  _size(node) {
    let count = node.keys.length;
    if (!node.isLeaf) {
      for (const child of node.children) {
        count += this._size(child);
      }
    }
    return count;
  }

  /** Print tree structure */
  print() {
    console.log(this.toString());
  }

  /** Get string representation */
  toString() {
    if (this.root.keys.length === 0) return '(empty tree)';
    const lines = [];
    this._buildString(this.root, '', true, lines);
    return lines.join('\n');
  }

  /** @private */
  _buildString(node, prefix, isLast, lines) {
    const connector = isLast ? '└── ' : '├── ';
    lines.push(prefix + connector + `[${node.keys.join(', ')}]`);
    
    if (!node.isLeaf) {
      const newPrefix = prefix + (isLast ? '    ' : '│   ');
      for (let i = 0; i < node.children.length; i++) {
        this._buildString(
          node.children[i],
          newPrefix,
          i === node.children.length - 1,
          lines
        );
      }
    }
  }

  /**
   * Validate B-tree invariants
   * @throws {Error} if invariants are violated
   */
  validate() {
    if (this.root.keys.length === 0) {
      if (!this.root.isLeaf || this.root.children.length > 0) {
        throw new Error('Empty tree should have empty leaf root');
      }
      return true;
    }
    
    const leafDepth = this._checkLeafDepth(this.root, 0);
    this._validate(this.root, null, null, true, leafDepth, 0);
    return true;
  }

  /** @private */
  _checkLeafDepth(node, depth) {
    if (node.isLeaf) return depth;
    return this._checkLeafDepth(node.children[0], depth + 1);
  }

  /** @private */
  _validate(node, minKey, maxKey, isRoot, expectedLeafDepth, currentDepth) {
    const t = this.t;
    
    // Check key count
    if (!isRoot && node.keys.length < t - 1) {
      throw new Error(`Node has ${node.keys.length} keys, min is ${t - 1}`);
    }
    if (node.keys.length > 2 * t - 1) {
      throw new Error(`Node has ${node.keys.length} keys, max is ${2 * t - 1}`);
    }
    
    // Check keys are sorted and in bounds
    for (let i = 0; i < node.keys.length; i++) {
      if (i > 0 && node.keys[i] <= node.keys[i - 1]) {
        throw new Error('Keys not sorted');
      }
      if (minKey !== null && node.keys[i] <= minKey) {
        throw new Error('Key violates min bound');
      }
      if (maxKey !== null && node.keys[i] >= maxKey) {
        throw new Error('Key violates max bound');
      }
    }
    
    // Check leaf depth
    if (node.isLeaf) {
      if (currentDepth !== expectedLeafDepth) {
        throw new Error('Leaves not at same depth');
      }
      if (node.children.length !== 0) {
        throw new Error('Leaf has children');
      }
    } else {
      // Check children count
      if (node.children.length !== node.keys.length + 1) {
        throw new Error(`Node has ${node.keys.length} keys but ${node.children.length} children`);
      }
      
      // Validate children
      for (let i = 0; i < node.children.length; i++) {
        const childMin = i === 0 ? minKey : node.keys[i - 1];
        const childMax = i === node.keys.length ? maxKey : node.keys[i];
        this._validate(node.children[i], childMin, childMax, false, expectedLeafDepth, currentDepth + 1);
      }
    }
  }
}

module.exports = { BTree, BTreeNode };
