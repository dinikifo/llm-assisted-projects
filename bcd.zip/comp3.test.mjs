import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  PackedBCD,
  decodeComp3,
  encodeComp3,
  comp3ByteLength,
  BCDError,
  BCDInvalidDigitError,
  BCDOverflowError,
  BCDParseError,
} from '../index.mjs';

const B = (s, opts) => PackedBCD.fromString(s, opts);
const bytes = (...b) => Uint8Array.of(...b);
const hex = (u8) => Array.from(u8, (b) => b.toString(16).padStart(2, '0')).join(' ');

// ---------------------------------------------------------------- fixtures
// Classic textbook COMP-3 encodings (PIC S9(5) unless noted).

test('encode: known fixtures', () => {
  assert.equal(hex(encodeComp3(B('1234', { width: 3 }))), '01 23 4c');
  assert.equal(hex(encodeComp3(B('-1234', { width: 3 }))), '01 23 4d');
  assert.equal(hex(encodeComp3(B('12345', { width: 3 }))), '12 34 5c');
  assert.equal(hex(encodeComp3(B('1234', { width: 3 }), { signed: false })), '01 23 4f');
  assert.equal(hex(encodeComp3(B('0', { width: 2 }))), '00 0c'); // PIC S9(3)
});

test('encode: implied decimal lives in the PIC, not the bytes', () => {
  // PIC S9(3)V99 holding -123.45 -> same bytes as -12345
  assert.equal(hex(encodeComp3(B('-123.45', { width: 3 }))), '12 34 5d');
});

test('decode: known fixtures', () => {
  assert.equal(decodeComp3(bytes(0x01, 0x23, 0x4c)).toString(), '1234');
  assert.equal(decodeComp3(bytes(0x01, 0x23, 0x4d)).toString(), '-1234');
  assert.equal(decodeComp3(bytes(0x12, 0x34, 0x5d), { scale: 2 }).toString(), '-123.45');
  assert.equal(decodeComp3(bytes(0x01, 0x23, 0x4f)).toString(), '1234');
});

test('decode: width equals the field byte length', () => {
  const v = decodeComp3(bytes(0x12, 0x34, 0x5c));
  assert.equal(v.width, 3);
  assert.equal(v.toHex(), '01 23 45'); // right-aligned in our layout
});

test('decode: liberal sign-nibble acceptance', () => {
  for (const s of [0x0a, 0x0c, 0x0e, 0x0f]) {
    assert.equal(decodeComp3(bytes(0x00, 0x10 | s)).toString(), '1', `sign 0x${s.toString(16)}`);
  }
  for (const s of [0x0b, 0x0d]) {
    assert.equal(decodeComp3(bytes(0x00, 0x10 | s)).toString(), '-1', `sign 0x${s.toString(16)}`);
  }
});

test('decode: invalid sign nibble is a decimal data exception', () => {
  assert.throws(() => decodeComp3(bytes(0x12, 0x34)), BCDInvalidDigitError); // sign 0x4
  assert.throws(() => decodeComp3(bytes(0x12, 0x39)), BCDInvalidDigitError); // sign 0x9
});

test('decode: invalid digit nibble throws', () => {
  assert.throws(() => decodeComp3(bytes(0x1a, 0x3c)), BCDInvalidDigitError); // low of byte 0
  assert.throws(() => decodeComp3(bytes(0xa1, 0x3c)), BCDInvalidDigitError); // high of byte 0
  assert.throws(() => decodeComp3(bytes(0x11, 0xac)), BCDInvalidDigitError); // digit above sign
});

test('decode: input validation', () => {
  assert.throws(() => decodeComp3(bytes()), BCDParseError);
  assert.throws(() => decodeComp3([0x1c]), BCDParseError); // plain array
});

test('decode: negative zero canonicalizes to +0', () => {
  const z = decodeComp3(bytes(0x00, 0x0d));
  assert.ok(z.isZero());
  assert.equal(z.sign, 1);
});

// -------------------------------------------------------------- round-trips

test('round-trip: decode(encode(v)) preserves value, scale, and size', () => {
  for (const s of ['0', '7', '12345', '-12345', '123.45', '-0.01', '99999']) {
    const v = B(s, { width: 3, scale: s.includes('.') ? 2 : 0 });
    const wire = encodeComp3(v);
    assert.equal(wire.length, 3, s);
    const back = decodeComp3(wire, { scale: v.scale });
    assert.ok(back.equals(v), `${s}: got ${back.toString()}`);
  }
});

test('round-trip: encode(decode(bytes)) reproduces canonical wire bytes', () => {
  for (const wire of [bytes(0x01, 0x23, 0x4c), bytes(0x12, 0x34, 0x5d), bytes(0x00, 0x0c)]) {
    assert.equal(hex(encodeComp3(decodeComp3(wire))), hex(wire));
  }
  // non-preferred signs normalize to preferred on the way back out
  assert.equal(hex(encodeComp3(decodeComp3(bytes(0x01, 0x2a)))), '01 2c');
  assert.equal(hex(encodeComp3(decodeComp3(bytes(0x01, 0x2b)))), '01 2d');
});

// ------------------------------------------------------------- field sizing

test('explicit digits controls the field size', () => {
  assert.equal(hex(encodeComp3(B('42'), { digits: 7 })), '00 00 04 2c'); // PIC S9(7) = 4 bytes
  assert.equal(hex(encodeComp3(B('42'), { digits: 2 })), '04 2c'); // even digit count pads
  assert.throws(() => encodeComp3(B('999', { width: 2 }), { digits: 2 }), BCDOverflowError);
});

test('comp3ByteLength matches COBOL field sizing', () => {
  assert.equal(comp3ByteLength(1), 1);
  assert.equal(comp3ByteLength(3), 2);
  assert.equal(comp3ByteLength(5), 3);
  assert.equal(comp3ByteLength(7), 4);
  assert.equal(comp3ByteLength(18), 10); // classic max PIC S9(18)
  assert.throws(() => comp3ByteLength(0), BCDError);
});

test('unsigned fields reject negative values', () => {
  assert.throws(() => encodeComp3(B('-1'), { signed: false }), BCDError);
});

// ------------------------------------------------- interop torture: records

test('slicing COMP-3 fields out of a fixed-layout record', () => {
  // A record with three fields:
  //   AMOUNT   PIC S9(5)V99 COMP-3  (4 bytes)  = -31415.92
  //   QTY      PIC 9(3)     COMP-3  (2 bytes)  = 250 (unsigned)
  //   BALANCE  PIC S9(9)    COMP-3  (5 bytes)  = 123456789
  const record = bytes(
    0x31, 0x41, 0x59, 0x2d,
    0x25, 0x0f,
    0x12, 0x34, 0x56, 0x78, 0x9c
  );
  const amount = decodeComp3(record.subarray(0, 4), { scale: 2 });
  const qty = decodeComp3(record.subarray(4, 6));
  const balance = decodeComp3(record.subarray(6, 11));
  assert.equal(amount.toString(), '-31415.92');
  assert.equal(qty.toString(), '250');
  assert.equal(balance.toString(), '123456789');
  // and the decoded values plug straight into arithmetic
  assert.equal(qty.toNumber() * 2, 500);
  assert.equal(
    amount.add(B('0.08', { width: 4, scale: 2 })).toString(),
    '-31415.84'
  );
});

test('randomized round-trip against reference', () => {
  let seed = 0xbcd;
  const rnd = (n) => ((seed = (seed * 1103515245 + 12345) & 0x7fffffff), seed % n);
  for (let i = 0; i < 500; i++) {
    const n = rnd(2 * 10 ** 9) - 10 ** 9;
    const v = PackedBCD.fromNumber(n, { width: 6 });
    const wire = encodeComp3(v, { digits: 11 });
    assert.equal(wire.length, comp3ByteLength(11));
    assert.equal(decodeComp3(wire).toNumber(), n, String(n));
  }
});
