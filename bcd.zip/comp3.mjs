/**
 * IBM packed-decimal (COBOL COMP-3) codec.
 *
 * Wire format: decimal digits packed two per byte, most significant digit
 * first, with the SIGN in the low nibble of the LAST byte. A field declared
 * PIC S9(n) COMP-3 occupies ceil((n + 1) / 2) bytes; when n is even the top
 * nibble of the first byte is a zero pad.
 *
 *   +1234  (PIC S9(5))  ->  01 23 4C
 *   -1234  (PIC S9(5))  ->  01 23 4D
 *    1234  (PIC  9(5))  ->  01 23 4F   (unsigned)
 *
 * Sign nibbles: hardware and compilers accept any of 0xA-0xF on input
 * (0xB and 0xD mean negative, the rest positive) but write the "preferred"
 * values 0xC / 0xD / 0xF. This codec does the same: liberal on decode,
 * canonical on encode. Anything below 0xA in the sign position — or any
 * digit nibble above 9 — is the equivalent of a decimal data exception
 * and throws BCDInvalidDigitError.
 *
 * The decimal point in COMP-3 is IMPLIED by the picture clause (the V in
 * PIC S9(3)V99) and never stored in the bytes. Pass it as `scale` when
 * decoding; on encode, the value's own scale is assumed to match the
 * target field's V position.
 */

import {
  PackedBCD,
  BCDError,
  BCDInvalidDigitError,
  BCDOverflowError,
  BCDParseError,
} from './bcd.mjs';

const NEGATIVE_SIGNS = new Set([0x0b, 0x0d]);
const POSITIVE_SIGNS = new Set([0x0a, 0x0c, 0x0e, 0x0f]);

const SIGN_POSITIVE = 0x0c;
const SIGN_NEGATIVE = 0x0d;
const SIGN_UNSIGNED = 0x0f;

/**
 * Decode a COMP-3 field into a PackedBCD.
 *
 * @param {Uint8Array} bytes raw field bytes (e.g. sliced from a record buffer)
 * @param {object} [opts]
 * @param {number} [opts.scale=0] implied decimal digits (the V position of the PIC clause)
 * @returns {PackedBCD} value with width equal to the field's byte length
 */
export function decodeComp3(bytes, { scale = 0 } = {}) {
  if (!(bytes instanceof Uint8Array) || bytes.length === 0) {
    throw new BCDParseError('decodeComp3 expects a non-empty Uint8Array');
  }
  const signNibble = bytes[bytes.length - 1] & 0x0f;
  let sign;
  if (NEGATIVE_SIGNS.has(signNibble)) sign = -1;
  else if (POSITIVE_SIGNS.has(signNibble)) sign = 1;
  else {
    throw new BCDInvalidDigitError(
      `invalid COMP-3 sign nibble 0x${signNibble.toString(16)} ` +
        `(expected 0xA-0xF); this field is probably not packed decimal`
    );
  }

  // Digit nibbles: every nibble except the sign. 2 * len - 1 digits total.
  const digits = new Array(bytes.length * 2 - 1);
  for (let i = 0; i < bytes.length; i++) {
    const hi = bytes[i] >> 4;
    const lo = bytes[i] & 0x0f;
    if (hi > 9) {
      throw new BCDInvalidDigitError(
        `invalid COMP-3 digit nibble 0x${hi.toString(16)} in byte ${i} (high)`
      );
    }
    digits[2 * i] = hi;
    if (i < bytes.length - 1) {
      if (lo > 9) {
        throw new BCDInvalidDigitError(
          `invalid COMP-3 digit nibble 0x${lo.toString(16)} in byte ${i} (low)`
        );
      }
      digits[2 * i + 1] = lo;
    }
  }

  // Re-pack right-aligned into our sign-magnitude layout. Width equals the
  // field's byte length, so encode(decode(bytes)) round-trips the size.
  return new PackedBCD(sign, packDigits(digits, bytes.length), scale);
}

/**
 * Encode a PackedBCD as a COMP-3 field.
 *
 * @param {PackedBCD} value its scale is assumed to match the field's implied V
 * @param {object} [opts]
 * @param {number} [opts.digits] field digit count (the n of PIC S9(n));
 *   defaults to 2 * value.width - 1, which round-trips decode()'s sizing
 * @param {boolean} [opts.signed=true] false writes the 0xF unsigned nibble
 *   and rejects negative values
 * @returns {Uint8Array} ceil((digits + 1) / 2) bytes
 */
export function encodeComp3(value, { digits, signed = true } = {}) {
  if (!(value instanceof PackedBCD)) {
    throw new BCDError('encodeComp3 expects a PackedBCD instance');
  }
  const fieldDigits = digits ?? value.width * 2 - 1;
  if (!Number.isInteger(fieldDigits) || fieldDigits < 1) {
    throw new BCDError(`digits must be a positive integer, got ${String(digits)}`);
  }
  if (!signed && value.sign < 0) {
    throw new BCDError('cannot encode a negative value into an unsigned COMP-3 field');
  }

  const mag = stripLeading(unpackBytes(value.bytes()));
  if (mag.length > fieldDigits && !(mag.length === 1 && mag[0] === 0)) {
    throw new BCDOverflowError(
      `value has ${mag.length} significant digits but the field holds ${fieldDigits}`
    );
  }

  const byteLen = Math.ceil((fieldDigits + 1) / 2);
  const out = new Uint8Array(byteLen);
  const signNibble = !signed
    ? SIGN_UNSIGNED
    : value.sign < 0
      ? SIGN_NEGATIVE
      : SIGN_POSITIVE;

  // Fill nibbles from the right: sign first, then digits LSD -> MSD.
  let nibble = byteLen * 2 - 1; // absolute nibble index, 0 = high nibble of byte 0
  setNibble(out, nibble--, signNibble);
  for (let i = mag.length - 1; i >= 0; i--) {
    setNibble(out, nibble--, mag[i]);
  }
  return out;
}

/** Field byte length for a PIC S9(n) COMP-3 declaration. */
export function comp3ByteLength(digits) {
  if (!Number.isInteger(digits) || digits < 1) {
    throw new BCDError(`digits must be a positive integer, got ${String(digits)}`);
  }
  return Math.ceil((digits + 1) / 2);
}

// ------------------------------------------------------------------ helpers

function setNibble(bytes, index, v) {
  const byte = index >> 1;
  if (index & 1) bytes[byte] |= v;
  else bytes[byte] |= v << 4;
}

function unpackBytes(bytes) {
  const d = new Array(bytes.length * 2);
  for (let i = 0; i < bytes.length; i++) {
    d[2 * i] = bytes[i] >> 4;
    d[2 * i + 1] = bytes[i] & 0x0f;
  }
  return d;
}

function stripLeading(d) {
  let i = 0;
  while (i < d.length - 1 && d[i] === 0) i++;
  return d.slice(i);
}

function packDigits(digits, width) {
  const out = new Uint8Array(width);
  let di = digits.length - 1;
  for (let i = width - 1; i >= 0 && di >= 0; i--) {
    const lo = digits[di--];
    const hi = di >= 0 ? digits[di--] : 0;
    out[i] = (hi << 4) | lo;
  }
  return out;
}
