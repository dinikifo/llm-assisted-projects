/**
 * Type declarations for packed-bcd.
 * The runtime is plain JavaScript; these declarations are maintained by hand
 * and checked in CI against test/types.check.mts.
 */

export type Sign = 1 | -1;
export type RoundingMode = 'truncate' | 'half-up';

export class BCDError extends Error {}
export class BCDInvalidDigitError extends BCDError {}
export class BCDParseError extends BCDError {}
export class BCDOverflowError extends BCDError {}
export class BCDWidthError extends BCDError {}
export class BCDScaleError extends BCDError {}
export class BCDDivisionByZeroError extends BCDError {}
export class BCDRoundingError extends BCDError {}

export interface ScaleRoundingOptions {
  /** Result scale (digits after the decimal point). */
  scale?: number;
  /** Rounding applied when reducing scale. */
  rounding?: RoundingMode;
}

/**
 * Immutable packed-BCD value: sign-magnitude, two digits per byte,
 * fixed width in bytes, fixed-point scale.
 * value = sign * magnitude / 10^scale
 */
export class PackedBCD {
  /** Low-level constructor; prefer fromString / fromNumber / zero. */
  constructor(sign: Sign, digits: Uint8Array, scale?: number);

  static zero(width?: number, scale?: number): PackedBCD;
  static fromString(str: string, opts?: { width?: number; scale?: number }): PackedBCD;
  /** Safe integers only; use fromString for fractional values. */
  static fromNumber(n: number, opts?: { width?: number; scale?: number }): PackedBCD;

  /** Width in bytes. */
  readonly width: number;
  /** Capacity in decimal digits (width * 2). */
  readonly precision: number;
  readonly scale: number;
  /** +1 or -1; always +1 for zero. */
  readonly sign: Sign;

  isZero(): boolean;
  /** Copy of the packed magnitude bytes. */
  bytes(): Uint8Array;

  /** Requires identical width and scale. */
  add(other: PackedBCD): PackedBCD;
  /** Requires identical width and scale. */
  sub(other: PackedBCD): PackedBCD;
  negate(): PackedBCD;
  abs(): PackedBCD;
  /** Requires identical width. Default scale: this.scale + other.scale. */
  mul(other: PackedBCD, opts?: ScaleRoundingOptions): PackedBCD;
  /** Requires identical width. Default scale: this.scale; default rounding: truncate. */
  div(other: PackedBCD, opts?: ScaleRoundingOptions): PackedBCD;

  rescale(newScale: number, rounding?: RoundingMode): PackedBCD;
  resize(newWidth: number): PackedBCD;

  /** Requires identical scale; widths may differ. */
  compareTo(other: PackedBCD): -1 | 0 | 1;
  /** Value equality at identical scale; widths may differ. Never throws. */
  equals(other: unknown): boolean;

  toString(): string;
  /** Raw packed bytes, e.g. "01 23". */
  toHex(): string;
  /** Convenience; may lose precision beyond 2^53. */
  toNumber(): number;
}

/**
 * Decode an IBM COMP-3 (COBOL packed decimal) field.
 * Scale is the implied decimal position (the V of the PIC clause).
 */
export function decodeComp3(bytes: Uint8Array, opts?: { scale?: number }): PackedBCD;

/**
 * Encode a PackedBCD as a COMP-3 field.
 * digits is the n of PIC S9(n); defaults to 2 * value.width - 1.
 */
export function encodeComp3(
  value: PackedBCD,
  opts?: { digits?: number; signed?: boolean }
): Uint8Array;

/** Field byte length for a PIC S9(n) COMP-3 declaration: ceil((n + 1) / 2). */
export function comp3ByteLength(digits: number): number;
