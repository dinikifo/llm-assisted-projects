# packed-bcd

Packed binary-coded-decimal arithmetic and an IBM COMP-3 (COBOL packed
decimal) codec for JavaScript. Fixed width, fixed point, immutable, zero
dependencies, no BigInt shortcuts.

[![ci](https://github.com/USERNAME/packed-bcd/actions/workflows/ci.yml/badge.svg)](https://github.com/USERNAME/packed-bcd/actions/workflows/ci.yml)

## Should you use this?

Be honest with yourself first:

- **You want exact decimal math in JS.** Use
  [decimal.js](https://github.com/MikeMcl/decimal.js) or
  [big.js](https://github.com/MikeMcl/big.js) — they are mature,
  arbitrary-precision, and faster. This library is not trying to compete.
- **You need to read or write COBOL COMP-3 / packed-decimal data** — EBCDIC
  fixed-layout records from banks, insurers, payroll systems, government
  batch files. That is the itch this scratches: a small, heavily tested
  codec plus a decimal value type that keeps the field semantics (fixed
  digit counts, implied decimal points) instead of flattening everything
  into floats.
- **You are writing an emulator or teaching decimal arithmetic.** The
  add/sub core is faithful to hardware BCD: binary nibble addition followed
  by the classic decimal-adjust (DAA) correction, sign-magnitude routing,
  borrow chains. Multiplication and long division are schoolbook algorithms
  on digit arrays — readable, not clever.

## Install

```sh
npm install packed-bcd
```

Requires Node >= 20 (uses `node:test` and ES modules). No runtime
dependencies.

## Quickstart

```js
import { PackedBCD, decodeComp3, encodeComp3 } from 'packed-bcd';

// Fixed-point values: width in bytes (2 digits/byte), scale = decimals
const price = PackedBCD.fromString('19.99', { width: 3 });
const qty   = PackedBCD.fromString('3',     { width: 3 });

const net = price.mul(qty);                       // 59.97 (scale 2)
const vat = net.mul(PackedBCD.fromString('0.24', { width: 3 }), { scale: 2 });
console.log(net.toString(), vat.toString());      // "59.97" "14.39"
console.log(net.toHex());                         // "00 59 97"

// Division requires you to choose precision and rounding — no surprises
const third = PackedBCD.fromString('1', { width: 4 })
  .div(PackedBCD.fromString('7', { width: 4 }), { scale: 6, rounding: 'half-up' });
console.log(third.toString());                    // "0.142857"
```

### COMP-3 records

```js
// AMOUNT PIC S9(5)V99 COMP-3 (4 bytes), QTY PIC 9(3) COMP-3 (2 bytes)
const record = Uint8Array.of(0x31, 0x41, 0x59, 0x2d, 0x25, 0x0f);

const amount = decodeComp3(record.subarray(0, 4), { scale: 2 }); // -31415.92
const qty    = decodeComp3(record.subarray(4, 6));               // 250

// ...and back out, with explicit field sizing
encodeComp3(amount, { digits: 7 });               // 4 bytes, sign nibble 0xD
encodeComp3(qty, { digits: 3, signed: false });   // 2 bytes, sign nibble 0xF
```

The decoder is liberal (accepts all six sign nibbles `0xA`–`0xF`, as
hardware does); the encoder always writes the preferred `0xC`/`0xD`/`0xF`.
Invalid digit or sign nibbles throw `BCDInvalidDigitError` — the software
equivalent of a decimal data exception, and a useful tripwire when your
record layout is off by a byte.

## Semantics in one paragraph

A `PackedBCD` is `sign × magnitude / 10^scale`, stored as two digits per
byte in a fixed number of bytes. Everything is immutable; every operation
returns a new value and never widens silently — results that don't fit the
operand width throw `BCDOverflowError`, the exception-flavored version of a
carry flag. `add`/`sub` demand identical width **and** scale;
`mul`/`div` demand identical width and let you pick the result scale and
rounding (`'truncate'` or `'half-up'`, ties away from zero). Conversions
are always explicit: `rescale()` changes the decimal point (rounding if it
drops digits), `resize()` changes storage (throwing if it would lose
digits). Strictness is a feature: in fixed-layout data, a silent widening
is a corrupted record waiting to happen.

## API

| | |
|---|---|
| `PackedBCD.fromString(s, {width?, scale?})` | parse `"−12.34"`-style literals |
| `PackedBCD.fromNumber(n, {width?, scale?})` | safe integers only |
| `PackedBCD.zero(width?, scale?)` | canonical zero |
| `.add(b)` / `.sub(b)` | same width & scale required |
| `.mul(b, {scale?, rounding?})` | default scale: sum of scales |
| `.div(b, {scale?, rounding?})` | default: dividend's scale, truncate |
| `.rescale(scale, rounding?)` / `.resize(width)` | explicit conversions |
| `.negate()` / `.abs()` / `.compareTo(b)` / `.equals(b)` | |
| `.toString()` / `.toHex()` / `.toNumber()` / `.bytes()` | |
| `.width` / `.precision` / `.scale` / `.sign` / `.isZero()` | |
| `decodeComp3(bytes, {scale?})` | COMP-3 → `PackedBCD` |
| `encodeComp3(value, {digits?, signed?})` | `PackedBCD` → COMP-3 |
| `comp3ByteLength(digits)` | `ceil((n+1)/2)` field sizing |

All errors extend `BCDError`: `BCDInvalidDigitError`, `BCDParseError`,
`BCDOverflowError`, `BCDWidthError`, `BCDScaleError`,
`BCDDivisionByZeroError`, `BCDRoundingError`.

TypeScript declarations are included and checked in CI.

## Testing

```sh
npm test          # node:test, 50+ tests
npm run check     # tests + tsc on the declarations
```

The suites include randomized cross-checks of all four operations against
BigInt reference arithmetic and COMP-3 round-trips against known fixture
bytes.

## Roadmap

- `divmod()` exposing the remainder
- `'half-even'` (banker's) rounding
- Zoned-decimal codec (`PIC S9(n)` DISPLAY with overpunch signs)
- EBCDIC record-layout helpers (possibly as a separate package)

## License

[CC0 1.0 Universal](./LICENSE) — public-domain dedication. Do anything you
like with this code; attribution is appreciated but not required.
